package edu.neu.madcourse.numad21su_shanness;

public interface ItemClickListener {

    void onItemClick(int position);

    void onCheckBoxClick(int position);

}
